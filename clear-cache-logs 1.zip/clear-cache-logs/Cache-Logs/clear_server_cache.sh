#!/bin/bash

Date=$(date +"%d_%b_%Y")
Time=$(date +"%I_%M")

Log_Path=/opt/clear-cache-logs/Cache-Logs/


Backup_File=/opt/clear-cache-logs/Cache-Logs/Cache-$Date-$Time.log
Free=/opt/clear-cache-logs/Cache-Logs/Free.txt

clear
cd
find -L $Log_Path -type f -mtime +2 -delete

echo -e "---------------------------------------------------------------------------------
`free -h`
---------------------------------------------------------------------------------\n" > $Free

if [ 1 -gt 0 ]
then
	
	echo -e "\033[1;33m\nBefore Delete the Cache\033[00m"
	cat $Free
	sync; echo 1 > /proc/sys/vm/drop_caches
	sync; echo 2 > /proc/sys/vm/drop_caches
	sync; echo 3 > /proc/sys/vm/drop_caches

	echo -e "\033[1;33mAfter Delete the Cache\033[00m
---------------------------------------------------------------------------------
`free -h`
---------------------------------------------------------------------------------\n
\033[1;32mCache_is_cleared_on	|	\033[1;35m`date`\033[00m \n\n"
	
fi > $Backup_File
